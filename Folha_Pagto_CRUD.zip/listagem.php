<?php
$conn = new mysqli("localhost", "root", "", "Folha_Pagto");

$sql = "SELECT * FROM tb_funcionarios";
$result = $conn->query($sql);
?>

<h2>DEMONSTRATIVO DE RENDIMENTOS MENSAIS</h2>
<table border="1" cellpadding="5">
<tr>
  <th>Nº Registro</th>
  <th>Nome</th>
  <th>Data Admissão</th>
  <th>Cargo</th>
  <th>Qtde Salários</th>
  <th>Salário Bruto</th>
  <th>INSS</th>
  <th>Salário Líquido</th>
  <th>Ações</th>
</tr>

<?php
if ($result->num_rows > 0) {
  while ($row = $result->fetch_assoc()) {
    echo "<tr>
      <td>{$row['N_Registro']}</td>
      <td>{$row['Nome_Funcionario']}</td>
      <td>{$row['data_admissao']}</td>
      <td>{$row['cargo']}</td>
      <td>{$row['qtde_salarios']}</td>
      <td>R$ {$row['salario_bruto']}</td>
      <td>R$ {$row['inss']}</td>
      <td>R$ {$row['salario_liquido']}</td>
      <td><a href='excluir.php?id={$row['N_Registro']}'>Excluir</a></td>
    </tr>";
  }
} else {
  echo "<tr><td colspan='9'>Nenhum funcionário cadastrado.</td></tr>";
}
$conn->close();
?>
</table>
<br>
<a href="home_funcionarios.php">Cadastrar Novo</a>