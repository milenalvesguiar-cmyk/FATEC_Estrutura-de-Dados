<?php
$conn = new mysqli("localhost", "root", "", "Folha_Pagto");

$nome = $_POST['nome'];
$data_admissao = $_POST['data_admissao'];
$cargo = $_POST['cargo'];
$qtde_salarios = $_POST['qtde_salarios'];
$salario_bruto = $_POST['salario_bruto'];

// Regra do INSS
if ($salario_bruto > 1550.00) {
    $inss = $salario_bruto * 0.11;
} else {
    $inss = 0;
}

$salario_liquido = $salario_bruto - $inss;

$sql = "INSERT INTO tb_funcionarios 
(Nome_Funcionario, data_admissao, cargo, qtde_salarios, salario_bruto, inss, salario_liquido)
VALUES ('$nome', '$data_admissao', '$cargo', '$qtde_salarios', '$salario_bruto', '$inss', '$salario_liquido')";

if ($conn->query($sql) === TRUE) {
    echo "Funcionário cadastrado com sucesso!<br>";
    echo "<a href='listagem.php'>Ver lista</a>";
} else {
    echo "Erro: " . $conn->error;
}

$conn->close();
?>