<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastro de Funcionários</title>
</head>
<body>
  <h2>Cadastro de Funcionários</h2>
  <form action="gravar.php" method="post">
    Nome: <input type="text" name="nome"><br><br>
    Data de Admissão: <input type="date" name="data_admissao"><br><br>
    Cargo: <input type="text" name="cargo"><br><br>
    Qtde Salários: <input type="number" name="qtde_salarios"><br><br>
    Salário Bruto: <input type="number" step="0.01" name="salario_bruto"><br><br>
    <input type="submit" value="Gravar">
  </form>
  <br>
  <a href="listagem.php">Listar Funcionários</a>
</body>
</html>